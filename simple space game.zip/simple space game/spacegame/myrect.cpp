
#include "myrect.h"
#include<QDebug>
#include<QGraphicsScene>
#include<QKeyEvent>
#include<Bullet.h>
#include"enemy.h"
void myRect::keyPressEvent(QKeyEvent *event)
{
    if(event->key()==Qt::Key_Left){
        if(x()>0){
            setPos(x()-10,y());
        }
    }


    if(event->key()==Qt::Key_Right){
        if(x()+100<800){
        setPos(x()+10,y());
        }
    }



    if(event->key()==Qt::Key_Space){
        Bullet* bullet= new Bullet();
        bullet->setPos(x()+48,y()-50);

        scene()->addItem(bullet);
    }


}

myRect::myRect()
{
    setPixmap(QPixmap(":/images/retro-airplane-or-aeroplane-icon-flat-old-vintage-aircraft-isolated-on-white-background-vector-illustration-travel-transportation-symbol-start-up-2EW8KTH-removebg-preview"));

}

void myRect::spawn()
{
    Enemy * enemy = new Enemy();
    scene()->addItem(enemy);

}
