
#include "game.h"
#include"QObject"
#include"QTimer"
#include"QImage"
#include<QApplication>
Game::Game()
{
    scene =new QGraphicsScene();
    player=new myRect();
    setBackgroundBrush(QBrush(QImage(":/images/6f0f5fc4ea58173c66424c599ca05247")));


    scene->addItem(player);

    player->setFlag(QGraphicsItem::ItemIsFocusable);
    player->setFocus();

    setScene(scene);
    setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);

    setFixedSize(800,600);
    setSceneRect(0,0,800,600);

    player->setPos(width()/2,height() -player->pixmap().height());

    QTimer *timer=new QTimer();
    QObject::connect(timer,SIGNAL(timeout()),player,SLOT(spawn()));
    timer->start(2000);

    score=new Score();
    scene->addItem(score);

    health=new Health();
    health->setPos(health->x(),health->y()+25);
    scene->addItem(health);




    show();

}

