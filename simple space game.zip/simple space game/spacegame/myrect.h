
#ifndef MYRECT_H
#define MYRECT_H

#include<QGraphicsPixmapItem>
#include<QPixmap>
#include<QObject>

class myRect:public QObject,public QGraphicsPixmapItem
{
  Q_OBJECT
public:
    void keyPressEvent(QKeyEvent* event);
    myRect();
public slots:
    void spawn();
};

#endif // MYRECT_H
