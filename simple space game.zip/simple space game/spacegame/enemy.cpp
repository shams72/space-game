
#include "enemy.h"
#include<stdlib.h>
#include <QTimer>
#include<QGraphicsScene>
#include<QDebug>
#include<game.h>

extern Game* game;
Enemy::Enemy()
{
    int random_number=rand()%700;
    setPos(random_number,0);

     setPixmap(QPixmap(":/images/pixel-art-8-bit-arcade-fighter-air-plane-red-vector-27629942-removebg-preview"));


    QTimer* timer=new QTimer();


    connect(timer,SIGNAL(timeout()),this,SLOT(move()));

    timer->start(50);

}

void Enemy::move()
{
    setPos(x(),y()+10);
    if(pos().y() >600){
        game->health->decrease();
        scene()->removeItem(this);
        delete this;

    }

}

