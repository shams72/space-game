
#include <QApplication>
#include<QGraphicsScene>
#include"myrect.h"
#include<QGraphicsView>
#include<QTimer>
#include<game.h>

Game* game;


int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

   /* QGraphicsScene *scene =new QGraphicsScene();
    myRect* player=new myRect();
    player->setRect(0,0,100,100);
    scene->addItem(player);

    player->setFlag(QGraphicsItem::ItemIsFocusable);
    player->setFocus();

    QGraphicsView* view=new QGraphicsView(scene);
    view->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    view->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    view->show();
    view->setFixedSize(800,600);
    view->setSceneRect(0,0,800,600);

    player->setPos(view->width()/2,view->height() -player->rect().height());

    QTimer *timer=new QTimer();
    QObject::connect(timer,SIGNAL(timeout()),player,SLOT(spawn()));
    timer->start(2000);*/

    game = new Game();
    game->show();




    return a.exec();
}
